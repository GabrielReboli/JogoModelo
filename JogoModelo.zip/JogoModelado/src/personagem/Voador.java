/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package personagem;

/**
 *
 * @author Gabriel
 */
/**
 * Classe Voador que representa um tipo de personagem que pode voar.
 * Estende a classe abstrata Personagem.
 * A classe Voador possui um método para voar e uma implementação do método abstrato desenhar.
 */
public class Voador extends Personagem{
    
    /**
     * Método que representa a ação de voar do personagem voador.
     */
    public void voar(){
        System.out.println("Voando...");
    }

    /**
     * Implementação obrigatória do método abstrato desenhar da classe Personagem.
     */
    @Override
    public void desenhar() {
    }
    
}
