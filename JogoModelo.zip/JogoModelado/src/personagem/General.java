/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package personagem;

/**
 *
 * @author alunolab08
 */

/**
 * Classe General que representa um personagem terrestre que pode falar.
 * Estende a classe abstrata Terrestre e implementa a interface Falar.
 * A classe General possui métodos para desenhar a aparência do personagem e para a ação de falar.
 */
public class General extends Terrestre implements Falar{

     /**
     * Método que exibe uma representação visual do General usando arte ASCII.
     */
    @Override
    public void desenhar() {

        System.out.println("       .---.\n" +
"      /_____\\\n" +
"      ( '.' )\n" +
"       \\_-_/_\n" +
"    .-\"`'V'//-.\n" +
"   / ,   |// , \\\n" +
"  / /|Ll //Ll|\\ \\\n" +
" / / |__//   | \\_\\\n" +
" \\ \\/---|[]==| / /\n" +
"  \\/\\__/ |   \\/\\/\n" +
"   |/_   | Ll_\\|\n" +
"     |`^\"\"\"^`|\n" +
"     |   |   |\n" +
"     |   |   |\n" +
"     |   |   |\n" +
"     |   |   |\n" +
"     L___l___J\n" +
"      |_ | _|\n" +
"     (___|___)\n" +
"      ^^^ ^^^");   
    }

    /**
     * Método de implementação obrigatória da interface Falar.
     */
    @Override
    public void falar() {
    }
    
}
