/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package personagem;

/**
 *
 * @author alunolab08
 */
/**
 * Classe lutSUMO que representa um lutador de sumô, um personagem terrestre que pode falar.
 * Estende a classe abstrata Terrestre e implementa a interface Falar.
 * A classe lutSUMO possui métodos para desenhar a aparência do lutador de sumô e para a ação de falar.
 */
public class lutSUMO extends Terrestre implements Falar{

    @Override
    public void desenhar() {
        System.out.println("      __W__\n" +
"     /X___X\\\n" +
"    (/= j =\\)\n" +
"     Y  ^  Y\n" +
"    _/' - '\\_\n" +
"  |      ,    \\\n" +
"   `.  )/7/ .) \\\n" +
"     Y.__/__Y \\ \\\n" +
"    [________] \\)/\n" +
"   /   |  |   \\\n" +
"  (  .-'--'-.  )\n" +
"   \\ )      ( /\n" +
"    ) )    ( (\n" +
"   (_/      \\_)");
    }

    /**
     * Método de implementação obrigatória da interface Falar.
     * Aqui, a implementação é deixada vazia, pois não há uma ação específica de fala definida para o lutador de sumô.
     */
    @Override
    public void falar() {
    }
    
}
