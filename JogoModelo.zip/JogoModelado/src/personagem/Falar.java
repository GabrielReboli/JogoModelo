/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package personagem;

/**
 *
 * @author Gabriel
 */
/**
 * Interface Falar, que define um método falar().
 * Classes que implementam essa interface devem fornecer uma implementação para o método falar().
 * Essa interface é usada para representar a capacidade de um personagem falar.
 */
public interface Falar {
    
    /**
     * Método que representa a ação de falar.
     * Classes que implementam esta interface devem fornecer sua própria lógica de fala.
     */
     public void falar();
        
   
}
