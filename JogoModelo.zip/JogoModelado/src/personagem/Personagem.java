/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package personagem;

import armas.Arma_IF;

/**
 *
 * @author alunolab08
 */

/**
 * Classe abstrata Personagem que define o comportamento básico de um personagem.
 * Um personagem pode ter uma arma e possui métodos abstratos para desenhar sua aparência.
 * Também possui métodos para utilizar a arma e configurar a arma do personagem.
 */
public abstract class Personagem{
    private Arma_IF arma;
    
    
    /**
     * Método abstrato para desenhar a aparência do personagem.
     * Cada classe que estende Personagem deve fornecer sua própria implementação desse método.
     */
    public abstract void desenhar();
    
     /**
     * Método para utilizar a arma do personagem.
     * Chama o método usarArma() da arma associada ao personagem.
     */
    public void arma(){
        arma.usarArma();
    }
    
    /**
     * Método para configurar a arma do personagem.
     */
    public void setArma(Arma_IF arma){
     this.arma = arma;
    }
  
    /**
     * Método para obter a arma atual do personagem.
     * retorna a arma associada ao personagem.
     */
    public Arma_IF getArma() {
        return arma;
    }
    
    public void enfrentar(Personagem oponente) {
        System.out.println(getClass().getSimpleName() + " está enfrentando " + oponente.getClass().getSimpleName() + "!");
        System.out.println("Atacando com " + arma.getClass().getSimpleName() + ":");
        arma.usarArma();
    }
    
    
    
}
