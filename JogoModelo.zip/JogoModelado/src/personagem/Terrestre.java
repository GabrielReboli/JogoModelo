/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package personagem;

/**
 *
 * @author Gabriel
 */
/**
 * Classe Terrestre que representa um tipo de personagem que pode se movimentar no solo.
 * Estende a classe abstrata Personagem.
 * A classe Terrestre possui um método para correr e uma implementação do método abstrato desenhar.
 */
public class Terrestre extends Personagem{
    
    /**
     * Método que representa a ação de correr do personagem terrestre.
     */
    public void correr(){
        System.out.println("Correndo...");
    }

    /**
     * Implementação obrigatória do método abstrato desenhar da classe Personagem.
     */
    @Override
    public void desenhar() {
    }
    
    
}
