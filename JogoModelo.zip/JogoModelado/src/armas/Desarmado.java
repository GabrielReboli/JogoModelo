/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package armas;

/**
 *
 * @author alunolab08
 */
/**
 * Classe Desarmado que implementa a interface Arma_IF, representando uma arma desarmada.
 * A classe Desarmado fornece uma implementação do método usarArma(), que exibe uma representação visual de não ter uma arma.
 */
public class Desarmado implements Arma_IF{

    /**
     * Método que representa a ação de utilizar a arma desarmada.
     * Exibe uma representação visual de não ter uma arma.
     */
    @Override
    public void usarArma() {
        System.out.println("                  _    ,-,    _\n" +
"                 ,--, /: :\\/': :`\\/: :\\\n" +
"                |`;  ' `,'   `.;    `: |\n" +
"                |    |     |  '  |     |.\n" +
"                | :  |     |     |     ||\n" +
"                | :. |  :  |  :  |  :  | \\\n" +
"                 \\__/: :.. : :.. | :.. |  )\n" +
"                      `---',\\___/,\\___/ /'\n" +
"                           `==._ .. . /'\n" +
"                                `-::-'");
    }
    
    
}
