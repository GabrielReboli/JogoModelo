/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package armas;

/**
 *
 * @author alunolab08
 */
/**
 * Classe Fuzil que implementa a interface Arma_IF, representando um fuzil como arma.
 * A classe Fuzil fornece uma implementação do método usarArma(), que exibe uma representação visual do fuzil sendo utilizado.
 */
public class Fuzil implements Arma_IF{

    /**
     * Método que representa a ação de utilizar o fuzil como arma.
     * Exibe uma representação visual do fuzil sendo utilizado.
     */
    @Override
    public void usarArma() {
        System.out.println("        |\\_______________ (_____\\\\______________\n" +
"HH======#H###############H#######################\n" +
"        ' ~\"\"\"\"\"\"\"\"\"\"\"\"\"\"`##(_))#H\\\"\"\"\"\"Y########\n" +
"                          ))    \\#H\\       `\"Y###\n" +
"                          \"      }#H)");
    }
    
}
