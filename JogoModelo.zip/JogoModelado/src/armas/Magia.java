/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package armas;

/**
 *
 * @author Gabriel
 */
/**
 * Classe Magia que implementa a interface Arma_IF, representando o uso de magia como arma.
 * A classe Magia fornece uma implementação do método usarArma(), que exibe uma representação visual do uso de magia.
 */
public class Magia implements Arma_IF{

    /**
     * Método que representa a ação de utilizar a magia como arma.
     * Exibe uma representação visual do uso de magia.
     */
    @Override
    public void usarArma() {
        System.out.println("*       *       * \n" +
"  *     *     *   \n" +
"    *   *   *     \n" +
"      * * *       \n" +
"* * * * * * * * * \n" +
"      * * *       \n" +
"    *   *   *     \n" +
"  *     *     *   \n" +
"*       *       * ");
    }
    
}
