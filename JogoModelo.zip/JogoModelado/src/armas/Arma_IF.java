/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package armas;

/**
 *
 * @author alunolab08
 */
/**
 * Interface Arma_IF que define o contrato para as classes que representam armas.
 * Classes que implementam esta interface devem fornecer uma implementação para o método usarArma().
 * Este método representa a ação de utilizar a arma.
 */
public interface Arma_IF {
    
  /**
     * Método que representa a ação de utilizar a arma.
     * As classes que implementam esta interface devem fornecer sua própria lógica para o uso da arma.
     */  
   public void usarArma();
}
