/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package armas;

/**
 *
 * @author Gabriel
 */
/**
 * Classe Faca que implementa a interface Arma_IF, representando uma faca como arma.
 * A classe Faca fornece uma implementação do método usarArma(), que exibe uma representação visual da faca sendo utilizada.
 */
public class Faca implements Arma_IF{

    /**
     * Método que representa a ação de utilizar a faca como arma.
     * Exibe uma representação visual da faca sendo utilizada.
     */
    @Override
    public void usarArma() {
        System.out.println("                                                       ___\n" +
"                                                      |_  |\n" +
"                                                        | |\n" +
"__                      ____                            | |\n" +
"\\ ````''''----....____.'\\   ````''''--------------------| |--.               _____      .-.\n" +
" :.                      `-._                           | |   `''-----''''```     ``''|`: :|\n" +
"  '::.                       `'--.._____________________| |                           | : :|\n" +
"    '::..       ----....._______________________________| |                           | : :|\n" +
"      `'-::...__________________________________________| |   .-''-..-'`-..-'`-..-''-.    :|\n" +
"           ```'''---------------------------------------| |--'                         `'-'\n" +
"                                                        | |\n" +
"                                                       _| |\n" +
"                                                      |___|    ");
    }
    
}
