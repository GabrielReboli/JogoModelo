/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package armas;

/**
 *
 * @author alunolab08
 */
/**
 * Classe Revolver que implementa a interface Arma_IF, representando um revólver como arma.
 * A classe Revolver fornece uma implementação do método usarArma(), que exibe uma representação visual do revólver sendo utilizado.
 */
public class Revolver implements Arma_IF{

    /**
     * Método que representa a ação de utilizar o revólver como arma.
     * Exibe uma representação visual do revólver sendo utilizado.
     */
    @Override
    public void usarArma() {
        System.out.println(" +--^----------,--------,-----,--------^-,\n" +
" | |||||||||   `--------'     |          O\n" +
" `+---------------------------^----------|\n" +
"   `\\_,---------,---------,--------------'\n" +
"     / XXXXXX /'|       /'\n" +
"    / XXXXXX /  `\\    /'\n" +
"   / XXXXXX /`-------'\n" +
"  / XXXXXX /\n" +
" / XXXXXX /\n" +
"(________(                \n" +
" `------'           ");
    }
    
}
