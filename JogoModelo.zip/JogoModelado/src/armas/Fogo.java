/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package armas;

/**
 *
 * @author Gabriel
 */
/**
 * Classe Fogo que implementa a interface Arma_IF, representando um ataque de fogo como arma.
 * A classe Fogo fornece uma implementação do método usarArma(), que exibe uma representação visual do ataque de fogo.
 */
public class Fogo implements Arma_IF{

    /**
     * Método que representa a ação de utilizar o ataque de fogo como arma.
     * Exibe uma representação visual do ataque de fogo.
     */
    @Override
    public void usarArma() {
        System.out.println("                                                                  \n" +
"                                                                  \n" +
"                                                                  \n" +
"                                                                  \n" +
"                                ▒▒                                \n" +
"                                ▓▓                                \n" +
"                                ▓▓▓▓                              \n" +
"                                ████                              \n" +
"                              ░░████                              \n" +
"                              ██▓▓██                              \n" +
"                        ░░  ████▓▓▓▓    ▒▒                        \n" +
"                        ▓▓▒▒▓▓██▒▒▓▓  ██░░                        \n" +
"                      ▓▓██████▒▒▓▓▒▒████  ▒▒                      \n" +
"                      ██████▒▒▒▒▓▓▒▒██▒▒  ██                      \n" +
"                      ██▓▓▓▓░░▒▒████▓▓░░▒▒██  ░░                  \n" +
"                      ██▒▒▒▒░░▒▒▓▓██▓▓▓▓████▓▓░░                  \n" +
"                      ██▒▒▒▒░░▒▒████▓▓██▓▓████░░                  \n" +
"                      ██▒▒░░░░▒▒▓▓██▒▒██▒▒██▓▓░░                  \n" +
"                  ░░  ▒▒▒▒░░░░░░▒▒██░░▒▒▒▒▓▓██                    \n" +
"                    ██▓▓▓▓░░  ░░▒▒▒▒░░░░▒▒▓▓▓▓                    \n" +
"                    ░░██▓▓▒▒░░  ░░░░░░░░░░▓▓░░                    \n" +
"                      ░░▓▓░░░░        ░░▒▒░░                      \n" +
"                          ░░▒▒░░      ░░                          \n" +
"                                                                  \n" +
"                                                                  \n" +
"                                                                  \n" +
"                                                                  \n" +
"                                                                  \n" +
"                                                                  \n" +
"                                                                  ");
    }
    
    
}
