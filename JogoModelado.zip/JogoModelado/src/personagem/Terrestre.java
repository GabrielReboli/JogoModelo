/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package personagem;

/**
 *
 * @author Gabriel
 */
public class Terrestre extends Personagem{
    
    public void correr(){
        System.out.println("Correndo...");
    }

    @Override
    public void desenhar() {
    }
    
    
}
