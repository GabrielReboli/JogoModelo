/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package personagem;

/**
 *
 * @author alunolab08
 */
public class lutSUMO extends Terrestre implements Falar{

    @Override
    public void desenhar() {
        System.out.println("      __W__\n" +
"     /X___X\\\n" +
"    (/= j =\\)\n" +
"     Y  ^  Y\n" +
"    _/' - '\\_\n" +
"  |      ,    \\\n" +
"   `.  )/7/ .) \\\n" +
"     Y.__/__Y \\ \\\n" +
"    [________] \\)/\n" +
"   /   |  |   \\\n" +
"  (  .-'--'-.  )\n" +
"   \\ )      ( /\n" +
"    ) )    ( (\n" +
"   (_/      \\_)");
    }

    @Override
    public void falar() {
    }
    
}
