/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package personagem;

/**
 *
 * @author alunolab08
 */
public class Soldado extends Terrestre implements Falar{

    @Override
    public void desenhar() {
        System.out.println("       .---.\n" +
"  ___ /_____\\\n" +
" /\\.-`( '.' )\n" +
"/ /    \\_-_/_\n" +
"\\ `-.-\"`'V'//-.\n" +
" `.__,   |// , \\\n" +
"     |Ll //Ll|\\ \\\n" +
"     |__//   | \\_\\\n" +
"    /---|[]==| / /\n" +
"    \\__/ |   \\/\\/\n" +
"    /_   | Ll_\\|\n" +
"     |`^\"\"\"^`|\n" +
"     |   |   |\n" +
"     |   |   |\n" +
"     |   |   |\n" +
"     |   |   |\n" +
"     L___l___J\n" +
" jgs  |_ | _|\n" +
"     (___|___)\n" +
"      ^^^ ^^^");
    }

    @Override
    public void falar() {
    }
    
}
