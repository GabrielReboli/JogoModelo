/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package personagem;

/**
 *
 * @author Gabriel
 */
public class DragaoAlado extends Voador{

    @Override
    public void desenhar() {
        System.out.println("                    -,,,__\n" +
"                     \\    ``~~--,,__                /   /\n" +
"                     /              ``~~--,,_     //--//\n" +
"          _,,,,-----,\\              ,,,,---- >   (c  c)\\\n" +
"      ,;''            `\\,,,,----''''   ,,-'''---/   /_ ;___        -,_\n" +
"     ( ''---,;====;,----/             (-,,_____/  /'/ `;   '''''----\\ `:.\n" +
"     (                 '               `      (oo)/   ;~~~~~~~~~~~~~/--~\n" +
"      `;_           ;    \\            ;   \\   `  ' ,,'\n" +
"         ```-----...|     )___________|    )-----'''\n" +
"                     \\   /             \\   \\\\\n" +
"                     /  /,              `\\   \\\\\n" +
"                   ,'---\\ \\              ,---`,;,\n" +
"                         ```");
    }

   
    public void voar(){
        System.out.println("Voando...");
    }
}
