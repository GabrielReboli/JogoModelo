/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package armas;

/**
 *
 * @author alunolab08
 */
public class Desarmado implements Arma_IF{

    @Override
    public void usarArma() {
        System.out.println("                  _    ,-,    _\n" +
"                 ,--, /: :\\/': :`\\/: :\\\n" +
"                |`;  ' `,'   `.;    `: |\n" +
"                |    |     |  '  |     |.\n" +
"                | :  |     |     |     ||\n" +
"                | :. |  :  |  :  |  :  | \\\n" +
"                 \\__/: :.. : :.. | :.. |  )\n" +
"                      `---',\\___/,\\___/ /'\n" +
"                           `==._ .. . /'\n" +
"                                `-::-'");
    }
    
    
}
